# Prompt 02：多日 Replay 语料、正式缓存与完整 Policy–Value 训练

## 前置条件

先读取并核对：

```text
decision_agent_v1/README.md
outputs/decision_agent_v1/audits/interface_audit.json
outputs/decision_agent_v1/tiny_overfit/
outputs/decision_agent_v1/selfplay/
decision_agent_v1/contracts/action_semantics.json
```

本阶段只在以下条件成立时继续：

- `DecisionSampleV1` 已能从真实 replay 生成；
- 没有读取 `visualize.current` 等隐藏信息；
- smoke forward/backward 通过；
- tiny-overfit 的 Policy 和 Value loss 都明显下降；
- deterministic legal self-play 无非法动作和崩溃。

如前置条件未满足，先修复当前阶段，不创建第二套实现。

---

# 一、阶段目标

把当前 tiny prototype 推进成正式离线训练流程：

```text
多日 Replay
→ episode/date split
→ 可复用缓存数据集
→ Policy–Value 完整训练
→ 时间保留集评估
→ 可供 inference 加载的 best checkpoint
```

本阶段不实现：

```text
对手牌组 belief
搜索
PPO
self-play fine-tune
submission 打包
静态 summary/detail
```

---

# 二、Replay 数据范围与 split

复用：

```text
data/online_replay_importer.py
data/replay_dataset.py
decision_agent_v1/adapters/replay_adapter.py
```

不要重新实现 replay 下载器和 JSON parser。

## Split 原则

按完整日期和完整 episode 划分：

```text
train：较早日期
validation：之后的日期
test：最近保留日期
```

要求：

- 同一个 episode 只能属于一个 split；
- 同一天默认只属于一个 split；
- 输出每个 split 的日期、episode 数、decision 数；
- 检查 episode ID 交集为零；
- 不随机打散 decision 后再切分；
- 配置中允许显式指定日期；
- 未指定日期时，按可用日期排序生成建议 split，并写入报告，不静默决定。

## 首轮规模

先运行分层规模：

```text
small：几十局，用于确认缓存与训练
medium：数百局，用于确认吞吐和指标
full：当前可用全部训练日期
```

不要一开始扫描全部 20GB 后才发现 schema 错误。

---

# 三、正式缓存格式

在：

```text
outputs/decision_agent_v1/cache/
```

生成版本化缓存。

推荐结构：

```text
cache/
└── policy_value_v1_<schema_hash>/
    ├── manifest.json
    ├── schema.json
    ├── train/
    │   ├── shard_00000.pt
    │   └── ...
    ├── validation/
    ├── test/
    └── statistics.json
```

要求：

- shard 按 episode 边界写入，避免一个 episode 跨 shard；
- manifest 保存：
  - schema version；
  - action contract hash；
  - card vocabulary hash；
  - replay 来源日期；
  - episode IDs；
  - adapter commit/hash；
  - hidden-information audit 标记；
- 缓存可以被训练重复读取，不必每个 epoch 重新解析 JSON；
- 不保存原始完整隐藏状态；
- 保留必要的原始 option index 映射；
- 数据 tensor 与轻量 metadata 分离；
- 单 shard 大小可配置；
- 缓存构建支持断点续写；
- 发现 hash 不一致时拒绝混用旧缓存。

新增正式入口，例如：

```text
python -m decision_agent_v1.scripts.build_training_cache \
  --config decision_agent_v1/configs/policy_value_v1.yaml \
  --scale small
```

不要为每种 scale 创建不同脚本。

---

# 四、数据审计

缓存构建后输出：

```text
outputs/decision_agent_v1/audits/replay_corpus_audit.json
outputs/decision_agent_v1/audits/replay_corpus_audit.md
```

至少包括：

```text
日期范围
episode 数
decision 数
每局 decision 分布
每个 agent 样本数
WIN/DRAW/LOSS 分布
selection mode 分布
select type/context 分布
UNKNOWN 样本数
option 数量分布
card token 数量分布
history token 数量分布
UNK Card ID 比例
serial 引用匹配率
equivalence group 覆盖率
episode split 交集检查
date split 交集检查
```

另外检查：

- terminal outcome 是否始终从当前 agent 视角转换；
- 一局双方样本的终局标签是否相反或同时 DRAW；
- 同一 decision 的目标 option 是否在合法 option 范围内；
- `min_count/max_count` 与 target 长度是否一致；
- UNKNOWN 样本只参与 Value，不参与 Policy；
- 训练输入中不存在完整对手手牌和牌库内容。

---

# 五、正式训练器

完善：

```text
decision_agent_v1/training/train_policy_value.py
decision_agent_v1/training/evaluate_policy_value.py
```

## 训练目标

保持：

\[
L=L_{\text{policy}}+\lambda_VL_{\text{value}}
\]

默认：

```yaml
policy_loss_weight: 1.0
value_loss_weight: 0.5
```

第一轮不要引入更多辅助损失。

## Policy 样本权重

默认所有已知语义 decision 等权。

可以预留以下配置，但默认关闭：

```text
winner/loser outcome weighting
agent quality weighting
decision-context weighting
```

不要在没有可靠 agent rating 时擅自把获胜方动作当成完美动作，也不要直接丢弃失败方全部决策。

## Value 样本权重

继续使用 episode-balanced weighting：

\[
w_t=\frac{1}{N_{\text{decision in episode}}}
\]

batch 内重新归一化。

针对 WIN/DRAW/LOSS 类别失衡，可使用基于 train split 统计得到的 class weight，并写入 checkpoint metadata。

## 优化

默认使用：

```text
AdamW
gradient clipping
learning-rate warmup
cosine 或 plateau scheduler
mixed precision（GPU 时）
early stopping
```

配置中集中管理。

不要在训练代码里写死 Kaggle 路径。

---

# 六、Checkpoint 与恢复

保存：

```text
outputs/decision_agent_v1/checkpoints/
├── last.pt
├── best_policy.pt
├── best_value.pt
├── best_joint.pt
└── training_state.json
```

`best_joint.pt` 的选择指标使用固定、可解释的组合分数，例如：

```text
joint_score
= equivalence_aware_policy_accuracy
  - alpha * validation_value_log_loss
```

具体 alpha 写入配置和报告。

Checkpoint 必须包含：

```text
model state
optimizer state
scheduler state
epoch
global step
model config
data schema hash
action contract hash
card vocabulary hash
split dates
metrics
```

支持中断后恢复训练。

---

# 七、评估与校准

在 validation/test 上输出：

## Policy

```text
equivalence-aware accuracy
single-select accuracy
first-choice accuracy
sequence exact match
set exact match
option count accuracy
按 select context 分组指标
按 option count 分组指标
```

## Value

```text
WIN/DRAW/LOSS accuracy
macro F1
cross-entropy/log loss
Brier score
expected calibration error
按 turn bucket 的准确率和校准
按 terminal outcome 的 V(s) 分布
```

## 重要基线

至少比较：

```text
随机合法 option
最高频 option-type/context baseline
deterministic legal baseline
未训练模型
当前训练模型
```

评估脚本不能只输出训练模型的单一 accuracy。

---

# 八、Kaggle 训练入口

新建独立部署目录：

```text
kaggle_decision_agent_training/
```

保持为薄 kernel，不维护第二份独立源码。

优先使用代码 Dataset 或打包工具同步：

```text
decision_agent_v1/
data/state_schema.py
data/observation_parser.py
data/game_memory.py
data/replay_dataset.py
data/online_replay_importer.py
```

Kernel 负责：

```text
读取挂载 replay 数据
构建或读取缓存
训练
评估
写出 checkpoints 和 metrics
```

不要修改旧 `kaggle_training/` 的 PPO 路线来承载本版本。

输出统一位于 Kaggle working 目录中的：

```text
decision_agent_v1_outputs/
```

下载回本地后归档到：

```text
outputs/decision_agent_v1/
```

---

# 九、正式验收

本阶段完成标准：

1. small/medium/full 三种 scale 使用同一入口。
2. 缓存可重复读取，第二次训练无需重新解析 replay。
3. split 无 episode/date 污染。
4. 隐藏信息审计通过。
5. 完整训练可恢复。
6. `best_joint.pt` 可被独立加载并完成推理 forward。
7. Policy 指标显著高于随机与未训练模型。
8. Value log loss/Brier score优于类别先验 baseline。
9. 输出按 context 和 turn bucket 的失败分析。
10. Kaggle 训练入口可执行。

完成后只汇报：

```text
新增/修改文件
缓存规模与 hash
split 日期和 episode 数
训练耗时
best epoch
Policy 指标
Value 指标
主要失败 context
checkpoint 路径
下一阶段建议
```
