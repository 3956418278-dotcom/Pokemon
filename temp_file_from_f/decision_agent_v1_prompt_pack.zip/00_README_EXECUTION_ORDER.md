# Decision Agent V1：分阶段 Codex Prompt 使用顺序

这组 Prompt 的目标是把 `decision_agent_v1/` 从独立的 Policy–Value 原型推进到一个：

- 能稳定读取真实 replay；
- 能进行完整 Policy–Value 训练；
- 能在 simulator 中运行；
- 能使用确定性 fallback；
- 能经过受控 self-play 微调；
- 能封装为 Kaggle submission；
- 具有合理中等强度基线潜力的 agent。

这不是排名保证。最终水平仍取决于 replay 质量、牌组质量、训练规模、模拟器评估结果和比赛环境。但按顺序完成这些 Prompt，应该得到一个完整、可训练、可评估、可提交的 agent，而不是只有若干未接合的特征模块。

## 执行顺序

1. `01_policy_value_foundation.md`
   - 建立适配层、统一 DecisionSample、共享 Board Encoder、Policy Head、Value Head。
   - 完成 smoke、tiny-overfit 和合法 baseline 自对弈。

2. `02_replay_corpus_and_full_training.md`
   - 把多日 replay 转为正式缓存数据集。
   - 完成第一版完整 Policy–Value 训练和时间保留集评估。

3. `03_state_history_and_belief_upgrade.md`
   - 增强完整局面：Public Ledger、Recent Events、自身牌组计数、对手牌组 belief。
   - 对比基础模型，只有验证有效才进入主模型。

4. `04_inference_and_hybrid_agent.md`
   - 把 checkpoint 接成 simulator 可调用 agent。
   - 加入动作 contract、确定性 fallback、异常保护和低置信度回退。

5. `05_simulator_evaluation_and_shallow_search.md`
   - 建立固定种子、固定牌组、交叉对战评估。
   - simulator 能安全复制状态时，增加小规模 Value-guided rollout；不能复制时保持纯 Policy。

6. `06_conservative_selfplay_finetune.md`
   - 从 BC checkpoint 开始进行保守 PPO/self-play 微调。
   - 使用历史对手池、KL 约束和回归门禁，防止破坏正常行为。

7. `07_deck_specialization_and_submission.md`
   - 比较候选牌组，对最好牌组专项微调。
   - 生成 `main.py + deck.csv + 模型文件 + submission.tar.gz`。

8. `08_final_champion_selection.md`
   - 建立候选 checkpoint 联赛。
   - 根据固定评估矩阵选出最终 Champion，并生成最终审计报告。

## 使用规则

- 每次只把一份 Prompt 交给 Codex。
- Codex 必须先读取上一阶段报告和真实源码，再修改。
- 原则问题必须停下：
  - 可见性泄漏；
  - replay split 污染；
  - action contract 与审计冲突；
  - simulator 输出非法；
  - checkpoint 无法稳定加载。
- 非原则性问题继续修复，不要频繁询问。
- 每阶段都必须把产物写到 `outputs/decision_agent_v1/`，不要散落到仓库根目录。
- 不为每个小函数创建单独脚本；保留少量正式入口和集中测试。
- 后续阶段可以修改 `decision_agent_v1/`，但不应反向破坏现有 `data/`、`models/`、`training/` 主线。
- 不提前实现后续阶段。当前 Prompt 没有要求的内容保持接口预留即可。
