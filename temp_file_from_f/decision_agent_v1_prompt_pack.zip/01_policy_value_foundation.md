# Decision Agent V1：Policy–Value 联合训练 Codex 实现指令

在当前 Pokémon TCG 项目仓库中新建一个独立实现包：

```text
decision_agent_v1/
```

该目录实现一条与现有静态卡牌预训练、单卡融合主线并行的新路线：

```text
现有 Observation / Replay 接口
→ 统一 DecisionSample
→ 最小单卡实例表示
→ 完整局面编码
→ Policy Head：合法 Option 评分
→ Value Head：局面胜/平/负预测
```

本版本的核心目标是直接学习局面：

\[
h_t=\operatorname{BoardEncoder}(s_t)
\]

并基于同一个局面表示同时学习：

\[
\pi(a_t\mid s_t)
\]

和：

\[
V(s_t)
\]

单卡编码不是独立训练目标，也不先进行单卡预训练。它只负责把局面中的每张可见卡牌实例转换为 Board Encoder 可以使用的 token。

本轮完成：

```text
现有数据接口
→ DecisionSampleV1
→ Shared Board Encoder
→ Policy Head
→ Value Head
→ Policy–Value 联合 tiny-overfit
```

本轮暂不进入：

```text
静态 summary/detail 融合
卡牌文字编码
状态变化预测
对手 belief
Oracle Critic
PPO
正式自对弈训练
Kaggle 提交打包
```

---

# 一、核心设计原则

## 1. 目标是构造局面表示，不是先训练单卡表示

本版本不把 `CardInstanceEncoder` 当作独立训练阶段。

每张卡牌实例只做最小编码：

\[
c_i=
E_{\mathrm{card\_id}}(id_i)
+
E_{\mathrm{owner}}
+
E_{\mathrm{zone}}
+
E_{\mathrm{position}}
+
W_{\mathrm{dyn}}x_i^{dyn}
\]

随后立即把所有实例 token、全局状态和公开历史送入 Board Encoder：

\[
h_t=
\operatorname{BoardEncoder}
(c_1,\ldots,c_n,g_t,m_t)
\]

`Card ID embedding`、动态编码器和 Board Encoder 通过最终 Policy/Value 损失端到端共同更新。

不为单卡设计独立 checkpoint、独立预训练数据集或独立训练任务。

## 2. Policy 与 Value 共享同一个 Board Encoder

```text
Shared Board Encoder
├── Policy Head：比较当前合法 options
└── Value Head：预测当前可见局面的最终胜/平/负
```

Policy 学习 Replay 中实际采取的动作。

Value 学习从当前 agent 视角出发，该局最终结果：

```text
LOSS
DRAW
WIN
```

Value Head 输出三个 logits：

\[
z_t^{value}\in\mathbb R^3
\]

通过 softmax 得到：

\[
p_{\mathrm{loss}},p_{\mathrm{draw}},p_{\mathrm{win}}
\]

定义局面标量分数：

\[
V(s_t)=p_{\mathrm{win}}-p_{\mathrm{loss}}
\]

所以：

\[
V(s_t)\in[-1,1]
\]

这个标量只作为模型输出和后续搜索接口，不由人工局面公式直接给定。

## 3. Actor 和 Value 输入都遵守最终可见性

本轮 Policy Head 和 Value Head 都只读取 agent 当时真实可见的 observation。

Replay 中以下字段不得进入 `DecisionSampleV1`：

```text
visualize
visualize.current
完整对手手牌
完整对手牌库
完整隐藏 prize 内容
任何 agent 当时不可见的信息
```

完整信息只为未来 Oracle Critic 保留，本轮不接入。

## 4. Card ID 与 serial 始终分离

- `card_id`：卡牌规则身份；
- `serial`：本局中的具体卡牌实例。

同一个 Card ID 的不同 serial 形成不同实例 token。

serial 用于：

```text
实例追踪
区域变化
Option 到 CardInstance token 的引用
```

serial 不作为无界离散 embedding 直接送入模型。

## 5. 复用现有数据接口，保持现有模型主线只读

优先复用：

```text
data/state_schema.py
data/observation_parser.py
data/game_memory.py
data/replay_dataset.py
data/online_replay_importer.py
```

以源码中的真实类、函数和字段为准，不根据文档猜测接口。

保持以下现有模型模块只读：

```text
models/static_card_adapter.py
models/static_detail_aggregator.py
models/dynamic_instance_encoder.py
models/card_instance_fusion.py
models/board_tokenizer.py
models/board_transformer.py
models/dynamic_state_encoder.py
```

新版本当前不调用上述模型。

## 6. 第一版只使用 Card ID 词表，不使用静态 embedding

可以读取现有：

```text
card_id_to_index.json
```

作为 Card ID 到连续 index 的映射。

本版本不读取：

```text
card_summary
detail_tokens
CardEncoder checkpoint
静态融合 checkpoint
卡牌文字 token
```

新模型中的 Card ID embedding 随机初始化，并由 Policy/Value 联合损失端到端训练。

## 7. 数据划分按完整 episode/date

- 同一 episode 不得跨 train/validation/test；
- 最近日期作为时间保留集；
- 不按单个 decision 随机切分；
- 每局独立重建 `GameMemory`；
- 不跨局共享 serial 状态。

## 8. 运行产物统一管理

所有运行产物写入：

```text
outputs/decision_agent_v1/
```

建议结构：

```text
outputs/decision_agent_v1/
├── audits/
├── contracts/
├── cache/
├── checkpoints/
├── metrics/
├── tiny_overfit/
└── selfplay/
```

源码目录只保存源码、配置、正式 contract 和 README。

---

# 二、目录结构

创建：

```text
decision_agent_v1/
├── __init__.py
├── README.md
│
├── configs/
│   └── policy_value_v1.yaml
│
├── contracts/
│   ├── __init__.py
│   ├── schemas.py
│   ├── action_contract.py
│   └── action_semantics.json
│
├── adapters/
│   ├── __init__.py
│   ├── observation_adapter.py
│   ├── replay_adapter.py
│   ├── card_vocab_adapter.py
│   └── simulator_adapter.py
│
├── baseline/
│   ├── __init__.py
│   └── deterministic_legal_agent.py
│
├── data/
│   ├── __init__.py
│   ├── decision_dataset.py
│   └── collate.py
│
├── models/
│   ├── __init__.py
│   ├── card_instance_encoder.py
│   ├── board_encoder.py
│   ├── option_encoder.py
│   ├── multiselect_decoder.py
│   ├── policy_head.py
│   ├── value_head.py
│   └── policy_value_model.py
│
├── training/
│   ├── __init__.py
│   ├── losses.py
│   ├── train_policy_value.py
│   └── evaluate_policy_value.py
│
├── inference/
│   ├── __init__.py
│   └── policy_value_agent.py
│
├── scripts/
│   ├── audit_interfaces.py
│   ├── smoke_pipeline.py
│   ├── tiny_overfit.py
│   └── run_legal_selfplay.py
│
└── tests/
    ├── test_adapters.py
    ├── test_policy_value_model.py
    └── test_multiselect_decoder.py
```

可以根据现有源码的真实接口对文件名作小幅调整，但保持职责边界。

---

# 三、统一数据结构

在：

```text
decision_agent_v1/contracts/schemas.py
```

定义本版本自己的 dataclass 或 TypedDict。

## 1. CardInstanceView

表示当前 agent 可见的一张具体卡牌实例。

字段至少包括：

```text
card_id
card_index
serial
relative_owner
zone
zone_position

is_active
is_bench

hp
max_hp
attached_energy_counts
special_condition_flags
appear_this_turn
pre_evolution_count
tool_count

field_visibility_mask
```

要求：

- `relative_owner` 统一转为 self/opponent；
- 不使用 card name 或 card text 作为模型输入；
- 不可见或对该卡类型无意义的字段通过 mask 区分；
- 同一 Card ID 的不同 serial 保持为不同实例。

## 2. GlobalStateView

字段至少包括：

```text
turn
turn_action_count
is_first_player
relative_current_player

self_hand_count
opponent_hand_count
self_deck_count
opponent_deck_count
self_prize_count
opponent_prize_count
self_bench_count
opponent_bench_count

energy_attached
supporter_played
stadium_played
retreated

select_type
select_context
remain_damage_counter
remain_energy_cost
min_count
max_count

field_visibility_mask
```

字段以现有 observation 实际可获得内容为准。

## 3. HistoryView

从现有 `GameMemory` 和公开 logs 构造：

```text
最近若干公开事件
每种公开事件累计次数
公开 Card ID 出现次数
公开 serial 区域变化
当前回合动作位置
```

本轮只使用已经可靠实现的公开历史。

不在本轮构造对手完整牌组 belief。

## 4. OptionView

每个合法 option 独立表示。

字段至少包括：

```text
original_option_index
option_type
select_type
select_context

relative_player
area
position_index

card_id
card_index
serial
energy_type
damage_value

has_card_reference
has_serial_reference
equivalence_group
```

要求：

- 保留 `original_option_index`；
- 若 option 引用当前可见 serial，应能关联对应 contextual card token；
- option 中没有某字段时使用 mask/专用缺失值；
- 不把 option list 中的位置误当成稳定全局动作 ID。

## 5. DecisionSampleV1

字段至少包括：

```text
episode_id
agent_index
decision_index
step
turn
turn_action_count

cards
global_state
history
options

selected_option_indices
selected_equivalence_groups

min_count
max_count
selection_mode

terminal_outcome
episode_decision_count
```

其中：

```text
terminal_outcome ∈ {LOSS, DRAW, WIN}
```

必须从当前 `agent_index` 视角转换，不能直接使用固定 player 0 视角。

`episode_decision_count` 用于训练时进行 episode-balanced weighting。

---

# 四、Action semantics contract

搜索仓库中的：

```text
action_semantics.csv
equivalent_option_groups.csv
replay_decision_contract_audit
```

把已经审计确认的结果转换为：

```text
decision_agent_v1/contracts/action_semantics.json
```

至少按：

```text
select.type + select.context + option.type
```

记录：

```text
selection_mode
allows_duplicate
order_matters
canonical_sort_key
equivalence_rule
```

允许的 `selection_mode`：

```text
SINGLE
ORDERED_SEQUENCE
UNORDERED_UNIQUE_SUBSET
UNKNOWN
```

要求：

1. 严格从现有审计产物导入。
2. 不自行定义新的动作语义。
3. 未覆盖组合标为 `UNKNOWN`。
4. `UNKNOWN` 进入覆盖率报告。
5. `UNKNOWN` 暂时不进入 Policy loss。
6. Value loss仍可使用该决策点，因为 Value 只依赖局面与终局结果；但需要在指标中单独报告。
7. contract 保存来源路径与文件 hash。
8. 找不到审计产物时报告缺失，不自行生成伪 contract。

---

# 五、Adapter 层

## 1. replay_adapter.py

适配现有：

```text
data/replay_dataset.py
```

把现有 `ReplayDecisionSample` 转成 `DecisionSampleV1`。

要求：

- 复用现有 replay JSON 遍历；
- 复用现有 decision-point 抽取；
- 复用现有 GameMemory 更新时间顺序；
- 每局独立重置 memory；
- 使用 agent-visible observation；
- 保留 episode/date split；
- 计算当前 agent 视角的 `terminal_outcome`；
- 记录每局总 decision 数；
- 不重新实现第二套 replay parser。

## 2. observation_adapter.py

负责：

```text
现有 parser 输出
→ CardInstanceView
→ GlobalStateView
→ HistoryView
→ OptionView
```

职责包括：

```text
相对视角转换
字段 mask
Card ID 映射
serial 到实例位置映射
稳定 token 排序
原始 option index 保留
```

模型内部不直接读取原始 observation dict。

## 3. card_vocab_adapter.py

从配置指定路径读取 Card ID 词表。

需要提供：

```text
PAD index
UNK index
Card ID → 连续 index
连续 index → Card ID
```

只使用映射，不读取现有静态 embedding。

## 4. simulator_adapter.py

适配仓库已有 cg simulator/runtime。

负责：

```text
live observation
→ observation_adapter
→ policy_value_agent
→ 原始 option index list
```

模型和 baseline 不直接依赖 simulator 内部对象。

---

# 六、确定性合法基线

实现：

```text
baseline/deterministic_legal_agent.py
```

目标是验证：

```text
simulator 接口
动作数量
多选顺序
原始 option index 恢复
完整对局稳定性
```

不追求战术强度。

要求：

- SINGLE 使用稳定排序选一个合法 option；
- ORDERED_SEQUENCE 按 contract 和稳定规则返回；
- UNORDERED_UNIQUE_SUBSET 按 canonical sort key 返回；
- 返回数量满足 `minCount/maxCount`；
- UNKNOWN 使用保守且合法的稳定选择，并记录统计；
- 相同 observation 始终返回相同结果；
- 输出必须是当前 option list 的原始合法索引。

---

# 七、模型结构

默认参数：

```yaml
card_id_embedding_dim: 128
model_dim: 128
dynamic_hidden_dim: 64

board_layers: 2
board_heads: 4
board_ffn_dim: 256

dropout: 0.1
value_classes: 3
```

## 1. CardInstanceEncoder：局面输入层

对每个可见实例：

\[
c_i =
E_{\mathrm{card\_id}}(card\_index_i)
+ E_{\mathrm{owner}}
+ E_{\mathrm{zone}}
+ E_{\mathrm{position}}
+ W_{\mathrm{dyn}}d_i
\]

其中 \(d_i\) 包含：

```text
HP / max HP
附着能量计数
异常状态
active / bench 标志
appear_this_turn
进化数量
工具数量
字段 mask
```

要求：

- 输出 128 维；
- 该模块不单独训练；
- 不创建单卡预训练任务；
- 不创建单卡 checkpoint；
- 梯度来自 Policy loss 与 Value loss；
- serial 只用于引用与实例追踪；
- 未知 Card ID 使用 UNK。

## 2. BoardEncoder：共享局面编码器

稳定 token 顺序：

```text
[GLOBAL]
[HISTORY_SUMMARY]
self active
self bench
self hand
self public discard / prize / other public zones
opponent active
opponent bench
opponent public zones
其他公开实例
```

每个 token 加入：

```text
token type embedding
relative owner embedding
zone embedding
position embedding
```

经过两层 TransformerEncoder：

\[
H_t=\operatorname{Transformer}(X_t)
\]

输出：

```text
board_token = H_t[GLOBAL]
contextual_card_tokens
token masks
serial_to_token_index
```

其中：

\[
b_t=H_t^{[\mathrm{GLOBAL}]}\in\mathbb R^{128}
\]

`b_t` 同时供 Policy Head 和 Value Head 使用。

## 3. OptionEncoder

编码：

```text
option type
select type
select context
relative player
area
position
Card ID
energy type
damage/count fields
card/serial reference masks
```

若 option 引用了当前可见 serial：

```text
读取对应 contextual_card_token
```

若没有引用：

```text
使用 learned NO_CARD_REFERENCE token
```

得到：

\[
a_j\in\mathbb R^{128}
\]

## 4. Policy Head

对每个合法 option：

\[
x_j=
[b_t,\ a_j,\ b_t\odot a_j,\ b_t-a_j]
\]

\[
z_j^{policy}=\operatorname{MLP}(x_j)
\]

只在当前合法 options 上归一化。

Policy 输出：

```text
option logits
option mask
autoregressive multi-select state
```

## 5. MultiSelectDecoder

统一使用 autoregressive without-replacement decoder。

### SINGLE

在当前合法 options 上 softmax。

### ORDERED_SEQUENCE

\[
P(j_1,\ldots,j_k\mid s)
=
\prod_r P(j_r\mid s,j_{<r})
\]

每一步 mask 已选择项。

### UNORDERED_UNIQUE_SUBSET

先按 contract 的 canonical sort key 规范化 Replay target，再进行自回归训练。

### Equivalent options

若目标 equivalence group 为 \(G_r\)：

\[
P(G_r)=\sum_{j\in G_r}P(j)
\]

Policy loss：

\[
-\log P(G_r)
\]

选中一个等价项后更新 without-replacement mask。

## 6. Value Head

Value Head 只读取共享局面表示：

\[
z_t^{value}
=
\operatorname{MLP}_{value}(b_t)
\in\mathbb R^3
\]

三个类别顺序固定为：

```text
LOSS
DRAW
WIN
```

训练时：

\[
L_{\mathrm{value}}
=
\operatorname{CrossEntropy}
(z_t^{value},y_t)
\]

推理/分析时输出：

\[
V(s_t)=
P(\mathrm{WIN}\mid s_t)
-
P(\mathrm{LOSS}\mid s_t)
\]

不要把当前 Replay 动作、selected option 或后继状态直接输入 Value Head。

Value 评价的是采取后续最可能策略时当前局面的结果倾向；第一版通过 Replay 分布近似学习，后续再由 self-play 校准。

## 7. PolicyValueModel

统一 forward 接口返回：

```text
policy_logits
value_logits
board_embedding
contextual_card_tokens
option_mask
```

不要把 Policy 与 Value 做成两套独立 Board Encoder。

---

# 八、Dataset 与 collate

`decision_dataset.py` 包装现有 `ReplayDecisionDataset`。

支持：

```text
按完整 episode/date split
按 selection mode 过滤 Policy 样本
UNKNOWN 保留给 Value
限制最大 episode 数
限制最大 decision 数
按 select type/context 统计
按 terminal outcome 统计
```

`collate.py` 处理：

```text
变长 card tokens
变长 history
变长 options
变长 selected sequence

card mask
option mask
target sequence mask
value target
policy sample mask
episode balance weight
```

## Episode-balanced weighting

同一局可能产生大量 decision，不能让长局在 Value loss 中无限放大。

默认：

\[
w_t^{episode}
=
\frac{1}{N_{\mathrm{decision}}^{episode}}
\]

然后在 batch 内重新归一化。

Value loss 使用该权重。

Policy loss可先按 decision 等权；配置中预留是否使用 episode-balanced Policy weight。

---

# 九、联合训练目标

## 1. Policy loss

\[
L_{\mathrm{policy}}
=
-\sum_r\log P(G_r\mid s,j_{<r})
\]

只对已知 action semantics 的样本计算。

## 2. Value loss

\[
L_{\mathrm{value}}
=
\operatorname{CE}
(z_t^{value},y_t)
\]

使用 episode-balanced weight。

## 3. 总损失

\[
L
=
L_{\mathrm{policy}}
+
\lambda_V L_{\mathrm{value}}
\]

默认：

```yaml
policy_loss_weight: 1.0
value_loss_weight: 0.5
```

配置允许修改，但本轮不添加更多辅助损失。

本轮明确不实现：

```text
状态变化预测
PPO
Oracle Critic
belief loss
静态 retention
detail attention
人工局面评分标签
```

---

# 十、训练与评估指标

## Policy 指标

```text
policy_loss
single_select_accuracy
first_choice_accuracy
sequence_exact_match
set_exact_match
option_count_accuracy
equivalence_aware_accuracy
samples_by_selection_mode
samples_by_select_context
unknown_semantics_count
```

## Value 指标

```text
value_loss
win_draw_loss_accuracy
macro_f1
value_mean
value_std
value_by_terminal_outcome
value_by_turn_bucket
value_by_agent
```

同时输出混淆矩阵。

## 联合指标

```text
total_loss
shared_encoder_gradient_norm
card_id_embedding_gradient_norm
policy_head_gradient_norm
value_head_gradient_norm
```

需要验证共享 Board Encoder 同时收到两种损失的梯度。

---

# 十一、配置

创建：

```text
decision_agent_v1/configs/policy_value_v1.yaml
```

至少包括：

```yaml
data:
  replay_paths: []
  card_vocab_path: null
  action_contract_path: null
  output_root: outputs/decision_agent_v1

split:
  train_dates: []
  validation_dates: []
  test_dates: []

limits:
  max_episodes: null
  max_decisions: null

model:
  card_id_embedding_dim: 128
  model_dim: 128
  dynamic_hidden_dim: 64
  board_layers: 2
  board_heads: 4
  board_ffn_dim: 256
  dropout: 0.1

training:
  batch_size: 32
  learning_rate: 0.0003
  epochs: 20
  policy_loss_weight: 1.0
  value_loss_weight: 0.5
  episode_balance_value: true
  seed: 20260718
  device: cpu
```

源码中不硬编码本地绝对路径。

smoke 和 tiny-overfit 默认使用 CPU。

---

# 十二、脚本

## 1. audit_interfaces.py

读取少量真实 replay，输出：

```text
outputs/decision_agent_v1/audits/interface_audit.json
outputs/decision_agent_v1/audits/interface_audit.md
```

至少统计：

```text
成功解析 episode 数
有效 decision 数
terminal outcome 分布
selection mode 分布
UNKNOWN 组合
card instance 数量分布
option 数量分布
multi-select 分布
Card ID 映射缺失
serial 引用匹配率
equivalence group 覆盖率
每局 decision 数分布
visibility 检查
```

visibility 检查必须明确确认：

```text
DecisionSampleV1 未读取 visualize.current 等全知字段
```

## 2. smoke_pipeline.py

完成：

```text
真实 replay
→ Existing ReplayDecisionSample
→ DecisionSampleV1
→ collate
→ PolicyValueModel forward
→ Policy loss
→ Value loss
→ total loss
→ backward
```

输出：

```text
tensor shapes
policy/value loss
各模块 gradient 是否存在
NaN/Inf 检查
```

不保存 checkpoint。

## 3. tiny_overfit.py

使用 32—128 个真实 decision samples。

训练并记录：

```text
初始 total loss
最终 total loss
初始/最终 policy loss
初始/最终 value loss
Policy exact match
Value outcome accuracy
各模块梯度
```

建议 tiny batch 至少包含：

```text
两个或更多 episode
WIN 与 LOSS
SINGLE
至少一种 multi-select
```

验收目标：

```text
Policy loss 明显下降
Value loss 明显下降
无 NaN/Inf
Card ID embedding 获得梯度
Board Encoder 同时接收 Policy 与 Value 梯度
Policy Head 获得梯度
Value Head 获得梯度
模型能够记忆 tiny batch 的大部分可监督目标
```

## 4. run_legal_selfplay.py

用 `DeterministicLegalAgent` 完成少量 simulator 自对弈。

记录：

```text
completed episodes
crash count
invalid action count
timeout count
unknown context count
episode length
```

输出统一写入：

```text
outputs/decision_agent_v1/selfplay/
```

该脚本只验证 simulator adapter 和合法动作闭环，不用于训练 Value。

---

# 十三、测试范围

只创建三个集中测试文件。

## test_adapters.py

验证：

```text
card_id 与 serial 分离
relative owner 转换
terminal outcome 视角转换
隐藏信息不会进入 DecisionSampleV1
option 原始 index 可恢复
完整 episode split
真实 replay 可生成样本
```

## test_policy_value_model.py

验证：

```text
变长 batch forward
合法 option mask
Policy logits shape
Value logits shape = [batch, 3]
Policy loss backward
Value loss backward
联合 loss backward
Card ID embedding 获得梯度
Board Encoder 获得两类梯度
引用 card token 的 option 可编码
```

## test_multiselect_decoder.py

验证：

```text
SINGLE
ORDERED_SEQUENCE
UNORDERED_UNIQUE_SUBSET
already-selected mask
equivalence-group loss
原始 option index 恢复
```

不为每个函数创建独立临时脚本。

---

# 十四、README

在：

```text
decision_agent_v1/README.md
```

写清楚：

```text
该目录目标是学习完整局面 Policy 与 Value
单卡编码只是局面输入层
不进行独立单卡预训练
与现有静态/动态主线的关系
复用的现有数据接口
可见性边界
目录结构
四个运行命令
当前验收状态
下一阶段计划
```

下一阶段只在本轮通过后进入：

```text
完整 Replay Policy–Value 训练
按时间保留集评估
Value calibration
状态变化模型
模拟器中的 Value-guided 决策评估
```

---

# 十五、本轮完成标准

完成后汇报：

1. 新增和修改的文件列表。
2. 实际复用的现有类和函数。
3. `DecisionSampleV1` 最终字段。
4. Action semantics contract 来源及 hash。
5. visibility audit 结果。
6. terminal outcome 视角转换验证。
7. smoke forward/backward 结果。
8. tiny-overfit 的初始/最终 Policy loss。
9. tiny-overfit 的初始/最终 Value loss。
10. tiny-overfit 的 Policy 与 Value 指标。
11. deterministic legal selfplay 结果。
12. 当前 UNKNOWN action semantics。
13. 下一阶段需要解决的问题。

本轮最终要证明：

```text
现有 Replay / Observation
可以无隐藏信息泄漏地转换为完整局面样本；

最小 Card ID + 动态实例 token
可以组成共享 Board 表示；

共享 Board Encoder
可以同时训练合法动作 Policy
和局面胜/平/负 Value；

单卡编码不需要独立预训练，
而由局面级监督端到端更新。
```
