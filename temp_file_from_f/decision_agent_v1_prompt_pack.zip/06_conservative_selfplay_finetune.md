# Prompt 06：保守 Self-play PPO 微调

## 前置条件

必须已有：

```text
稳定的 hybrid agent
固定 simulator 评估协议
当前 champion checkpoint
至少一个历史/基线 opponent
```

本阶段目标是从行为克隆策略出发做保守强化学习，而不是从随机策略重新训练。

若 simulator 吞吐过低或复制/并行不稳定，先完成小规模 self-play，不强行扩大。

---

# 一、训练原则

初始化：

```text
Policy–Value best/champion checkpoint
```

保持：

```text
合法 action mask
action semantics contract
MultiSelectDecoder
当前可见性边界
GameMemory
```

Reward 第一版只使用：

```text
WIN = +1
DRAW = 0
LOSS = -1
```

不加入大量人工稠密奖励。

可以记录局面 Value 变化用于诊断，但默认不作为环境 reward。

---

# 二、PPO 数据定义

每个 selection decision 作为一个时间步：

```text
visible state
available options
selected option/sequence
old log probability
value prediction
reward
done
episode ID
agent side
```

多选动作：

- 将完整自回归 sequence 的 log probability 求和，作为该 decision 的 action log probability；
- 不把同一个 multi-select 拆成多个环境 reward 时间步；
- 保存每个 decoder step 的 mask 以便重算 log probability；
- equivalence group 使用与 BC 相同的概率定义。

---

# 三、GAE 与 PPO

实现：

```text
terminal reward propagation
GAE
clipped policy objective
clipped value loss
entropy bonus
gradient clipping
```

默认建议：

```yaml
ppo:
  gamma: 1.0
  gae_lambda: 0.95
  clip_range: 0.15
  value_clip_range: 0.2
  entropy_coef: 0.01
  value_coef: 0.5
  max_grad_norm: 1.0
```

由于 reward 只在终局，`gamma=1.0` 作为首个默认值，并通过实验确认。

---

# 四、BC/KL 保护

为防止 PPO 破坏正常行为，加入至少一种保护：

## 方案 A：对 BC reference 的 KL

冻结一份 BC champion：

\[
L_{\mathrm{KL}}
=
D_{\mathrm{KL}}
(\pi_{\mathrm{new}}\|\pi_{\mathrm{BC}})
\]

## 方案 B：混合 BC batch

每次 PPO update 混入少量 replay BC 样本。

推荐同时支持，默认先开启 KL，BC replay 可配置。

总损失：

\[
L=
L_{\mathrm{PPO}}
+c_VL_V
+c_{\mathrm{KL}}L_{\mathrm{KL}}
+c_{\mathrm{BC}}L_{\mathrm{BC}}
\]

所有系数集中配置。

---

# 五、对手池

建立：

```text
deterministic baseline
BC champion
过去若干 PPO checkpoint
当前 champion
不同牌组的固定 agent
```

采样默认：

```text
30% BC champion
30% 历史 checkpoint
20% 当前策略镜像
20% deterministic/其他 baseline
```

具体比例可配置。

要求：

- opponent checkpoint 冻结；
- 每轮保留历史快照；
- 不只和最新自己镜像训练；
- 记录每个对手的胜率；
- 防止单一 matchup 过拟合。

---

# 六、共享编码器冻结计划

分阶段：

## Stage A

```text
冻结 Card ID embedding 和大部分 Board Encoder
只训练 Policy Head、Value Head 和最后一层
```

确认 PPO 数据和 loss 正确。

## Stage B

解冻 Board Encoder 最后一层。

## Stage C

只有固定评估确认有收益时，才全量小学习率微调。

不要第一轮直接大幅更新整个模型。

---

# 七、训练门禁

每隔固定 update 运行短评估：

```text
vs BC champion
vs deterministic
vs historical pool
镜像
```

若出现：

```text
非法动作
crash
Value 发散
KL 过大
对 BC champion 胜率持续恶化
主要牌组 matchup 灾难性退化
```

停止并回滚到上一稳定 checkpoint。

保存：

```text
ppo_last.pt
ppo_best.pt
ppo_history/
```

`ppo_best.pt` 必须通过固定离线/在线门禁，而不是只看训练 reward。

---

# 八、并行与 Kaggle

优先支持少量并行环境，但不要假设 2 vCPU 可以高并发。

实现：

```text
单进程可靠模式
可配置 worker 数
固定种子
episode 超时
失败 episode 隔离
```

新建薄 kernel：

```text
kaggle_decision_agent_selfplay/
```

输出：

```text
selfplay trajectories summary
PPO metrics
evaluation snapshots
best checkpoint
```

---

# 九、指标

记录：

```text
episode return
win/draw/loss
opponent-specific win rate
policy loss
value loss
entropy
approx KL
clip fraction
explained variance
gradient norm
illegal/crash/timeout
episode length
```

对比：

```text
BC champion
PPO last
PPO best
```

---

# 十、验收

PPO checkpoint 只有同时满足以下条件才进入候选：

1. 无非法动作和 crash 增长。
2. 固定评估矩阵平均胜率不低于 BC。
3. 至少在一个主要对手/牌组上有稳定提升。
4. 主要 matchup 无灾难性退化。
5. KL、entropy、Value loss 未发散。
6. CPU 推理成本没有显著增加。
7. 可从 checkpoint 恢复训练。

完成后汇报：

```text
self-play 局数
对手池组成
PPO 参数
冻结/解冻阶段
BC vs PPO 评估
最佳 checkpoint
失败与回滚次数
是否升级 Champion
```
