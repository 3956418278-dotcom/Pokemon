# Prompt 08：最终 Champion 联赛、回归审计与交付

## 前置条件

已有一个或多个可提交候选：

```text
通用 BC Champion
增强局面 V2
PPO 候选
牌组专项候选
搜索开启/关闭候选
```

本阶段不再大规模增加新模型结构，只进行选择、回归修复和最终交付。

---

# 一、候选注册表

建立：

```text
outputs/decision_agent_v1/final/candidates.json
```

每个候选记录：

```text
candidate ID
checkpoint hash
config hash
card vocabulary hash
action contract hash
deck hash
belief assets hash
search config
submission package path
来源训练阶段
```

无法复现的候选不进入联赛。

---

# 二、最终评估矩阵

固定：

```text
多个对手
多个牌组 matchup
交换先后手
相同种子集合
足够 episode
```

至少比较：

```text
deterministic baseline
基础 BC
当前 hybrid
PPO 候选
最终牌组专项候选
```

对搜索开关也作为独立候选比较。

---

# 三、回归测试

对每个候选运行：

```text
action semantics 全覆盖测试
multi-select contract 测试
hidden-information audit
episode reset 测试
checkpoint cold load
空目录 submission import
100+ 完整对局稳定性
资源 benchmark
```

任何以下问题直接淘汰：

```text
非法动作
偶发 crash
memory 跨局污染
隐藏信息输入
hash 不匹配
submission 无法独立运行
超资源限制
```

---

# 四、Champion 选择

按优先级：

1. 合法性和稳定性。
2. 固定评估矩阵总体表现。
3. 最差主要 matchup。
4. 先后手鲁棒性。
5. 推理延迟与超时风险。
6. Value calibration 和 fallback 率。
7. 实现复杂度。

不要只根据一次小样本胜率选 Champion。

输出：

```text
final_league_results.json
final_matchup_matrix.csv
final_champion_report.md
```

---

# 五、最终版本冻结

冻结：

```text
final checkpoint
final deck.csv
final model config
final action contract
final vocabulary
final belief assets
final search config
final submission.tar.gz
```

写入：

```text
outputs/decision_agent_v1/final/RELEASE_MANIFEST.json
```

包含所有 SHA256。

---

# 六、项目文档更新

更新：

```text
decision_agent_v1/README.md
PROJECT_FILE_MANIFEST.md
README_KAGGLE_RUN.md
```

只增加本路线真实存在的内容。

写清楚：

```text
训练数据范围
模型结构
最终牌组
训练命令
评估命令
submission 构建命令
已知限制
回退策略
最终文件 hash
```

不要覆盖旧主线的历史说明。

---

# 七、最终交付

最终目录：

```text
outputs/decision_agent_v1/final/
├── submission.tar.gz
├── RELEASE_MANIFEST.json
├── final_champion_report.md
├── final_league_results.json
├── final_matchup_matrix.csv
├── submission_audit.md
└── known_limitations.md
```

`known_limitations.md` 必须如实说明：

```text
未覆盖/UNKNOWN action semantics
对手 belief 的限制
Value 的校准限制
未见牌组泛化限制
搜索是否启用
主要失败 matchup
```

---

# 八、完成汇报

最终只汇报：

1. Champion 候选 ID。
2. 最终牌组。
3. 最终 checkpoint。
4. 是否启用 belief。
5. 是否启用 search。
6. 对主要 baseline 的评估。
7. 最差 matchup。
8. submission 大小与延迟。
9. 稳定性测试结果。
10. `submission.tar.gz` 路径与 SHA256。
