# Prompt 03：局面历史、牌组上下文与对手 Belief 增强

## 前置条件

先读取：

```text
outputs/decision_agent_v1/audits/replay_corpus_audit.json
outputs/decision_agent_v1/metrics/
outputs/decision_agent_v1/checkpoints/best_joint.pt
decision_agent_v1/configs/policy_value_v1.yaml
```

只有当基础 Policy–Value 模型已经在时间保留集上优于随机、频率和未训练 baseline 时继续。

本阶段目标不是无限增加特征，而是补充基础模型明显缺失的三类局面信息：

```text
公开历史
自身牌组剩余结构
对手牌组概率 belief
```

所有增强都必须做消融。没有验证收益的模块保持关闭。

---

# 一、增强后的局面结构

共享 Board Encoder 输入扩展为：

```text
[GLOBAL]
[SELF_DECK_CONTEXT]
[OPPONENT_BELIEF]
[LEDGER_SUMMARY]
[RECENT_EVENT_1 ... RECENT_EVENT_K]
[VISIBLE_CARD_INSTANCE ...]
```

仍然只使用当前 agent 可获得的信息。

---

# 二、Public Ledger

在 `decision_agent_v1/` 内通过 adapter 读取现有 `GameMemory`，不要建立第二套互相冲突的日志系统。

Ledger 至少维护：

```text
按 relative owner 的公开 Card ID 出现次数
公开 Card ID 当前已知区域
serial 最近一次公开区域
累计 draw/search/discard/recover/attach/evolve/attack 等公开事件计数
当前回合各事件计数
supporter/stadium/retreat/energy attach 使用状态
```

要求：

- 只记录 agent 能看到的事件；
- 对手从隐藏区到隐藏区的变化不推断具体 Card ID；
- shuffle 后清除不再可靠的确定位置；
- serial 离开可见区域后，保留“曾公开”事实，但不伪造当前具体位置；
- 每项 Ledger 字段有明确语义和 mask；
- 输出固定维度 summary token 和必要的 per-card public count token。

---

# 三、Recent Events

保留最近 K 个公开事件，默认：

```yaml
recent_event_count: 16
```

每个事件 token 编码：

```text
event type
relative player
card ID（公开时）
source zone
target zone
turn distance
decision distance
within-turn action position
event visibility mask
```

加入相对时间位置编码：

```text
距离当前多少个 decision
距离当前多少个 turn
当前回合内先后顺序
```

不要把所有历史完整展开到无限长度。

---

# 四、Self Deck Context

自身 `deck.csv` 或 replay 中自己可见/已知的起始牌组是合法信息。

构造：

```text
初始牌组 Card ID counts
已知已抽取/场上/弃牌/奖赏等数量
按 Card ID 推算的 remaining count
按类别或可用字段聚合的 remaining summary
```

要求：

- live inference 从当前提交的 `deck.csv` 初始化；
- replay 训练从当前 agent 的完整初始牌组初始化，但不使用对手完整牌组；
- shuffle 不改变剩余 Card ID 总计，只改变顺序未知性；
- prize 中具体内容若 agent 不知道，则计入 remaining unknown，不泄漏具体 Card ID；
- Self Deck Context 输出一个 summary token，并可选输出高频 Card ID count tokens；
- 与 Card ID vocabulary 对齐。

---

# 五、Opponent Deck Belief

## 训练先验数据

可以使用 replay 的完整牌组列表离线构建“环境牌组先验”，但完整对手牌组只能用于：

```text
离线聚类/模板统计
belief 辅助标签
评估 belief 准确率
```

不能直接输入 Actor/Value。

从训练日期 replay 提取：

```text
完整 60 卡计数向量
Pokemon + Energy signature
常见 archetype/template
Card ID 共现频率
```

只使用 train split 建先验，validation/test 牌组不能泄漏回训练先验。

## Belief 更新

根据对手公开的 Card ID 逐步更新：

\[
P(D\mid R_t)\propto P(R_t\mid D)P(D)
\]

第一版实现可解释模板 posterior：

```text
archetype/template posterior
已公开 Card ID counts
每个模板与公开信息的一致程度
剩余可能 Card ID 的期望 counts
belief entropy
top-k template probabilities
```

不要一开始实现复杂生成式神经网络。

## Belief Token

编码：

```text
top-k archetype embedding 加权和
belief entropy
对手已公开卡数量
预期剩余 Pokemon/Trainer/Energy summary
高概率威胁 Card ID 的期望数量
```

只使用通过公开信息更新后的 posterior。

---

# 六、辅助监督

本阶段允许增加两个辅助头：

## 1. Opponent archetype prediction

从当前公开信息预测真实对手 archetype：

\[
L_{\text{archetype}}
\]

标签只在训练时使用。

## 2. Next public card prediction

预测对手后续新公开的 Card ID 或 Card group：

\[
L_{\text{next-public}}
\]

只预测未来首次公开信息，不要求预测精确手牌顺序。

总损失：

\[
L=
L_{\text{policy}}
+\lambda_VL_{\text{value}}
+\lambda_AL_{\text{archetype}}
+\lambda_NL_{\text{next-public}}
\]

默认辅助权重保持较小，并可关闭。

---

# 七、消融实验

至少训练并比较：

```text
A：基础模型
B：A + Ledger/Recent Events
C：B + Self Deck Context
D：C + Opponent Belief
```

所有版本：

- 使用相同 train/validation/test split；
- 相同训练预算；
- 相同随机种子集合；
- 报告参数量和推理耗时；
- 比较 Policy、Value 与 simulator 对战结果。

只有当模块满足以下至少一项时才默认启用：

```text
时间保留集 Policy 提升
Value calibration 提升
特定高影响 context 提升
simulator 胜率提升
```

如果只提升训练集，不进入默认配置。

---

# 八、缓存版本

因为 schema 发生变化，生成新的缓存版本：

```text
policy_value_v2_<schema_hash>
```

不要覆盖 V1 缓存。

manifest 额外记录：

```text
ledger schema
recent event count
deck prior source
archetype clustering version
belief template hash
```

---

# 九、输出

新增：

```text
outputs/decision_agent_v1/belief/
├── deck_templates.json
├── deck_template_metadata.json
├── card_cooccurrence.npz
└── belief_audit.md
```

新增消融报告：

```text
outputs/decision_agent_v1/metrics/state_upgrade_ablation.json
outputs/decision_agent_v1/metrics/state_upgrade_ablation.md
```

保存：

```text
best_joint_v2.pt
```

但只有消融通过时才将其标记为当前默认 checkpoint。

---

# 十、验收

完成后汇报：

1. Ledger 和 Recent Events 的最终字段。
2. Self Deck remaining counts 的更新规则。
3. 对手 deck prior 的训练日期和模板数量。
4. belief 是否严格只使用公开信息。
5. archetype 辅助准确率。
6. next-public 预测指标。
7. A/B/C/D 消融结果。
8. 推理 token 数和延迟变化。
9. 是否将 V2 设为默认。
10. 未改善的模块及关闭原因。
