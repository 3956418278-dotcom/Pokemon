# Prompt 05：固定评估联赛与 Value-guided 浅层搜索

## 前置条件

当前 hybrid agent 已能完成至少 100 局 simulator 对战，无非法动作和崩溃。

本阶段先建立可信评估，再决定是否加入浅层搜索。

---

# 一、固定评估协议

新建：

```text
decision_agent_v1/evaluation/
├── match_runner.py
├── opponent_registry.py
├── deck_registry.py
├── tournament.py
└── statistics.py
```

评估协议固定：

```text
相同牌组组合
交换先后手
固定种子集合
双向对局
相同 episode 数
完整记录 crash/timeout
```

每个候选至少对战：

```text
deterministic legal baseline
仓库现有可运行 baseline agent
纯 BC/Policy checkpoint
hybrid agent
上一版 champion
```

可用时再加入历史/公开 agent，不让缺失外部 agent 阻塞流程。

---

# 二、牌组矩阵

优先读取：

```text
baseline_decks.json
popular_test_decks.json（存在时）
```

建立小型但多样的牌组矩阵：

```text
当前计划提交牌组
至少 2 个不同 archetype
至少 1 个镜像对局
```

报告：

```text
按牌组 matchup 的胜率
先手/后手胜率
平均回合数
不同 context 的模型使用率
fallback rate
```

不要只在单一镜像牌组上判断 agent 强弱。

---

# 三、统计

输出：

```text
win rate
Wilson confidence interval
paired seed result
first-player bias
deck matchup matrix
crash/timeout/invalid rate
mean/95p latency
```

候选替换 Champion 的最低条件：

```text
合法性不下降
运行资源满足限制
固定评估矩阵平均胜率提高
没有某个主要 matchup 灾难性退化
```

样本不足时报告不确定性，不宣称确定提升。

---

# 四、检查 simulator 是否支持安全状态复制

只读检查 cg simulator/runtime：

```text
clone/copy state
serialize/deserialize state
deterministic seed restoration
step from copied state
```

先写一份：

```text
outputs/decision_agent_v1/audits/search_capability_audit.md
```

必须回答：

1. 能否复制完整内部状态？
2. 复制后是否与原状态隔离？
3. 随机数状态是否复制？
4. 能否从当前 pending selection 继续？
5. 一次 rollout 的平均开销？
6. submission 环境是否可用？

如果不能可靠复制，停止搜索实现，保留纯 hybrid agent，并继续完成评估体系。

---

# 五、Value-guided 浅层搜索

仅在状态复制审计通过时实现。

新增：

```text
decision_agent_v1/search/
├── rollout_policy.py
├── shallow_search.py
└── search_config.py
```

## 搜索对象

当前 simulator 的一个 `select` 往往是完整动作中的中间选择。

因此搜索不能简单把单个 option 后的中间状态当作最终后继局面。

对每个候选 option：

1. clone 当前 simulator 状态；
2. 应用该 option；
3. 使用当前 Policy 完成同一 effect/pending selection 链；
4. rollout 到以下最早边界：
   - 当前完整 effect 结束；
   - 当前 turn 结束；
   - 达到最大 decision depth；
   - 游戏终局；
5. 使用：
   - 终局 reward，或
   - Value Head 对 rollout 后局面评分。

## 候选剪枝

先用 Policy 取 top-k：

```yaml
search:
  top_k: 3
  max_decisions: 8
  max_rollouts_per_option: 2
```

参数需根据 CPU benchmark 调整。

## 搜索评分

\[
S(a)=
\alpha\log\pi(a\mid s)
+(1-\alpha)\bar V(s'_a)
\]

终局时直接使用 reward。

随机分支可做少量多次 rollout 取平均。

## 安全限制

- UNKNOWN semantics 默认不搜索；
- 搜索超时立即返回原 Policy 结果；
- clone/step 异常不影响主对局；
- 不修改真实 simulator 状态；
- 所有候选必须保持合法；
- submission 默认有严格搜索时间预算。

---

# 六、搜索消融

比较：

```text
Policy only
Hybrid without search
Hybrid + top-2 search
Hybrid + top-3 search
```

报告：

```text
胜率
置信区间
每步延迟
超时率
搜索触发率
搜索改变原 top-1 的比例
改变后胜率
```

只有在固定矩阵中有收益且不导致明显超时，才默认启用。

---

# 七、输出

生成：

```text
outputs/decision_agent_v1/evaluation/
├── tournament_results.json
├── matchup_matrix.csv
├── evaluation_report.md
└── search_ablation.md
```

保存当前 champion 指针：

```text
outputs/decision_agent_v1/checkpoints/champion.json
```

包含：

```text
checkpoint
config
deck set
search config
evaluation hash
```

---

# 八、验收

完成后汇报：

1. 固定评估协议。
2. 对手与牌组矩阵。
3. 当前 hybrid 对各 baseline 的结果。
4. 搜索能力审计结论。
5. 若实现搜索，搜索消融与延迟。
6. 当前 Champion。
7. 是否默认启用搜索。
8. 主要失败 matchup 和 context。
