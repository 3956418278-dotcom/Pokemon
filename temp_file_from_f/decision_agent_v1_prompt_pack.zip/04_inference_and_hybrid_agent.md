# Prompt 04：Simulator 推理、混合策略与稳定 Agent

## 前置条件

读取当前最佳 checkpoint、配置、action contract 和 vocabulary：

```text
outputs/decision_agent_v1/checkpoints/
decision_agent_v1/contracts/action_semantics.json
decision_agent_v1/configs/
```

本阶段目标是把离线模型接成一个真实可运行的 agent。

不进行大规模训练，不实现 PPO。

---

# 一、统一推理入口

完善：

```text
decision_agent_v1/inference/policy_value_agent.py
decision_agent_v1/adapters/simulator_adapter.py
```

对外接口必须接收 simulator 当前 observation，并返回：

```python
list[int]
```

其中每个整数都是当前 option list 的原始合法索引。

推理流程：

```text
raw observation
→ existing observation parser / GameMemory
→ DecisionSampleV1 inference view
→ collate single sample
→ PolicyValueModel
→ MultiSelectDecoder
→ original option indices
```

不得在 inference 内重新实现与训练不同的字段解析。

---

# 二、模型加载

实现稳定加载：

```text
checkpoint
model config
schema hash
action contract hash
card vocabulary hash
deck template/belief assets（启用时）
```

要求：

- hash 不匹配时清楚报错；
- submission 模式下发生加载错误时启动 deterministic fallback；
- CPU `map_location` 正确；
- `eval()` 与 `torch.no_grad()`；
- 固定随机种子；
- 默认使用 greedy decoding；
- 可配置 temperature，但 submission 默认 0/greedy；
- checkpoint 只加载一次，不在每个 action 重载。

---

# 三、动作解码

## Forced/Trivial decisions

以下情况不运行完整模型：

```text
没有 option：返回 []
只有一个合法 option 且数量要求唯一：直接返回该 option
所有 option 属于同一 equivalence group：按 canonical 规则返回
```

## 已知语义

使用 `MultiSelectDecoder`：

```text
SINGLE
ORDERED_SEQUENCE
UNORDERED_UNIQUE_SUBSET
```

严格满足：

```text
minCount
maxCount
without replacement
order contract
equivalence contract
```

## UNKNOWN

UNKNOWN 不交给未经训练的 Policy 直接猜测复杂序列。

使用：

```text
DeterministicLegalAgent
```

并记录计数。

---

# 四、低置信度回退

为模型输出计算：

```text
top-1 probability
top-1/top-2 margin
policy entropy
value confidence
```

配置支持：

```yaml
fallback:
  enabled: true
  min_top1_probability: ...
  min_margin: ...
  max_entropy: ...
```

但阈值不能凭空设定。

先在 validation replay 上统计：

```text
正确/错误决策的置信度分布
不同 context 的 calibration
```

再选择阈值。

回退策略：

```text
模型已知语义且置信度足够 → 模型
已知语义但低置信度 → context-safe deterministic policy
UNKNOWN → deterministic legal fallback
异常/NaN/shape mismatch → deterministic legal fallback
```

第一版 fallback 的目标是合法与稳定，不伪造未经审计的高级战术规则。

---

# 五、有限安全规则层

只允许实现经过以下来源确认的规则：

```text
action semantics audit
simulator API/源码
大量 replay 中一致的确定性语义
```

可以包括：

```text
强制选择
等价 option canonicalization
明显的 no-op/confirm/continue
固定 setup 数量要求
已经确认的顺序无关集合
```

不要自行编写大量卡牌策略规则。

任何策略性 heuristic 都要：

- 单独列在 `safe_heuristics.py`；
- 带来源说明；
- 可配置关闭；
- 在 simulator 中做消融。

---

# 六、GameMemory 生命周期

确保：

```text
新 episode 自动 reset
同一 episode 连续 decision 复用 memory
agent 视角变化不会污染
异常结束后 reset
```

增加明确的 episode/session key。

不要依赖进程重启来清空 memory。

---

# 七、延迟与资源

增加 benchmark：

```text
parse latency
board encode latency
option score latency
multi-select decode latency
total action latency
peak RAM
checkpoint size
```

测试：

```text
单 option
常见 option 数
最大观察 token 数
最大 multi-select
```

目标：

- CPU 推理稳定；
- 不在 action 路径写大量磁盘日志；
- 关闭 debug 后保持轻量；
- checkpoint 和依赖满足提交包限制。

---

# 八、模型代理与基线代理对战入口

新增统一 agent factory：

```text
make_deterministic_agent(...)
make_policy_value_agent(...)
make_hybrid_agent(...)
```

所有 simulator 评估使用相同接口。

增加：

```text
python -m decision_agent_v1.scripts.run_agent_match \
  --agent-a hybrid \
  --agent-b deterministic \
  --episodes 100
```

输出：

```text
wins/losses/draws
crashes
invalid actions
fallback rate
UNKNOWN rate
mean action latency
context-level fallback stats
```

---

# 九、验收

本阶段完成标准：

1. 模型可从 checkpoint 稳定加载。
2. 真实 simulator 完整对局无非法 index。
3. 所有 multi-select 数量与顺序合法。
4. UNKNOWN 和异常均可回退。
5. GameMemory 不跨局污染。
6. 100 局自对弈/交叉对战无 crash。
7. 推理延迟和内存报告完整。
8. model-only、fallback-only、hybrid 三种模式可比较。
9. hybrid 的合法性不低于 deterministic baseline。
10. 生成 `inference_readiness_report.md`。
