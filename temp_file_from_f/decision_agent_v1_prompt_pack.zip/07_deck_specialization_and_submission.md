# Prompt 07：牌组专项训练与 Kaggle Submission 封装

## 前置条件

当前至少有一个稳定 Champion：

```text
BC 或 PPO checkpoint
hybrid inference agent
固定评估结果
```

本阶段目标是选择一套实际提交牌组，并对该牌组专项优化，然后生成可验证 submission。

---

# 一、候选牌组

读取：

```text
baseline_decks.json
baseline_decks.md
popular_test_decks.json（存在时）
popular_deck_summary.csv（存在时）
```

构造候选列表，至少包含：

```text
当前稳定基线牌组
一个高频热门牌组
一个与当前环境差异较大的牌组
```

检查每套牌：

```text
60 卡
Card ID 合法
模拟器可加载
没有缺失卡
deck.csv 可生成
```

---

# 二、牌组专项输入

确保模型在 inference 时知道自己的完整牌组。

使用 Prompt 03 的 Self Deck Context：

```text
初始 Card ID counts
当前 known remaining counts
当前公开/已用资源
```

牌组不是只作为外部文件存在，而应进入局面表示。

---

# 三、牌组专项微调

对每套候选牌组分别：

1. 从通用 Champion 初始化；
2. 筛选该牌组相关 replay；
3. 进行小学习率 Policy–Value fine-tune；
4. 可选进行少量对手池 self-play；
5. 保存 deck-specific checkpoint。

不要为每套牌从零训练整个模型。

推荐保存：

```text
checkpoints/deck_specialized/<deck_key>/
```

每个目录包括：

```text
best.pt
config.yaml
deck.csv
training_metrics.json
evaluation.json
```

---

# 四、牌组选择联赛

对每个“牌组 + checkpoint”组合，运行固定矩阵：

```text
交换先后手
固定种子
对多个对手牌组
对多个 baseline/champion
```

评估：

```text
总体胜率
最差 matchup
先后手差
平均回合数
crash/timeout
推理延迟
fallback rate
```

选择标准不只看平均胜率，还要求：

```text
无明显灾难 matchup
运行稳定
提交资源可接受
```

---

# 五、Submission 目录

新建：

```text
kaggle_decision_agent_submission/
```

最终工作目录必须生成：

```text
main.py
deck.csv
model.pt 或压缩后的权重
model_config.json
card_vocab.json
action_semantics.json
必要的 belief/deck assets
submission.tar.gz
```

`main.py` 位于压缩包顶层。

不要把整个仓库、训练缓存、日志、测试和无关 checkpoint 打包进去。

---

# 六、运行路径

所有文件导入以：

```text
/kaggle_simulations/agent/
```

为根目录。

`main.py` 不依赖当前工作目录恰好是仓库根目录。

使用：

```python
Path(__file__).resolve().parent
```

定位资源。

---

# 七、提交推理策略

submission 默认使用：

```text
Hybrid agent
greedy decoding
UNKNOWN deterministic fallback
异常 deterministic fallback
已验证有效时才启用 shallow search
```

如果搜索未通过延迟和胜率消融，submission 默认关闭。

---

# 八、模型压缩与资源

检查：

```text
submission.tar.gz 大小
解压后大小
checkpoint 大小
首次加载时间
单步平均/95p 延迟
峰值 RAM
```

可以使用：

```text
state_dict-only checkpoint
FP16/BF16 存储（CPU 加载兼容时）
动态量化（验证不降级时）
TorchScript（真实环境验证通过时）
```

每种压缩都必须对比模型输出和 simulator 胜率。

不要为了减小体积引入不稳定依赖。

---

# 九、异常保护

`main.py` 必须：

```text
首次调用懒加载或模块级安全加载
捕获模型加载异常
捕获单步推理异常
输出始终为合法 list[int]
日志简洁
不泄漏隐藏状态
不无限重试
```

发生异常时使用 deterministic legal fallback。

---

# 十、本地/Kaggle 验证

构建 submission 后执行：

1. 解压到临时空目录。
2. 只使用压缩包内文件导入 `main.py`。
3. 自我验证对局。
4. 与 deterministic baseline 对局。
5. 模拟 `/kaggle_simulations/agent/` 路径。
6. 检查顶层文件结构。
7. 检查包大小。
8. 检查无绝对本地路径。
9. 检查无训练数据依赖。
10. 检查多局 memory reset。

输出：

```text
outputs/decision_agent_v1/submission/submission_audit.json
outputs/decision_agent_v1/submission/submission_audit.md
```

---

# 十一、生成命令

提供单一入口，例如：

```text
python -m decision_agent_v1.scripts.build_submission \
  --checkpoint ... \
  --deck ... \
  --output outputs/decision_agent_v1/submission
```

生成：

```text
submission.tar.gz
```

不要手动复制一堆文件作为正式流程。

---

# 十二、验收

完成标准：

1. 已选定明确的牌组与 checkpoint。
2. 牌组专项版本优于或不低于通用 Champion。
3. submission 包顶层结构正确。
4. 空目录导入成功。
5. self-validation 通过。
6. 至少 100 局本地/Kaggle simulator 无 crash 和非法动作。
7. 包大小、RAM、CPU 延迟满足限制。
8. fallback 路径真实测试通过。
9. 生成可直接提交的 `submission.tar.gz`。
10. README 记录准确提交命令和版本 hash。

完成后汇报：

```text
最终牌组
最终 checkpoint
专项训练收益
评估矩阵
submission 大小
推理延迟
自验证结果
submission.tar.gz 路径
```
